"use client"

import Proventos from "./Proventos"

export default function ProventosTab() {
  return (
    <div className="h-full">
      <Proventos />
    </div>
  )
}

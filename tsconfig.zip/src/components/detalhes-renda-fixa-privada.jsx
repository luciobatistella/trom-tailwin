"use client"

import { useState } from "react"
import { DetalhesBase } from "./detalhes-base"
import { formatCurrency } from "../utils/formatCurrency"

export default function DetalhesRendaFixa({ ativo, isVisible, onClose }) {
  const [showDetalhes, setShowDetalhes] = useState(false)
  const [showCondicoes, setShowCondicoes] = useState(false)

  if (!ativo) return null

  // Cálculos
  const valorizacao = (ativo.valueUpdated || 0) - (ativo.value || 0)
  const percentualValorizacao = ativo.value > 0 ? (valorizacao / ativo.value) * 100 : 0
  const isPositivo = valorizacao >= 0

  // Data atual
  const dataAtual = new Date()
  const horaFormatada = dataAtual.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  })
  const dataFormatada = dataAtual.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  })

  const actionButtons = (
    <div className="flex justify-between gap-3">
      <button
        className="bg-[#FDAA1A] hover:bg-[#F09800] text-white px-4 py-3 rounded-lg font-bold flex-1 transition-colors uppercase text-sm"
        onClick={() => console.log("Resgatar", ativo)}
      >
        <div className="flex items-center justify-center gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="17 8 12 3 7 8" />
            <line x1="12" y1="3" x2="12" y2="15" />
          </svg>
          Resgatar3
        </div>
      </button>
      <button
        className="bg-[#058CE1] hover:bg-[#006FB5] text-white px-4 py-3 rounded-lg font-bold flex-1 transition-colors uppercase text-sm"
        onClick={() => console.log("Investir", ativo)}
      >
        <div className="flex items-center justify-center gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="7 10 12 15 17 10" />
            <line x1="12" y1="15" x2="12" y2="3" />
          </svg>
          Investir
        </div>
      </button>
    </div>
  )

  return (
    <DetalhesBase
      isVisible={isVisible}
      onClose={onClose}
      title={ativo.cod || "Renda Fixa"}
      subtitle={ativo.description || ""}
      actionButtons={actionButtons}
    >
      {/* Valor Atual */}
      <div className="p-4 border-b border-[#404040]">
        <div className="flex justify-between items-center mb-2">
          <h4 className="text-sm font-semibold text-[#aaa] uppercase">Valor Atual</h4>
          <div className="text-xs text-[#888]">
            Atualizado hoje às {horaFormatada} ({dataFormatada})
          </div>
        </div>

        <div className="text-2xl font-bold text-white mb-2">{formatCurrency(ativo.valueUpdated || 0)}</div>

        <div className="flex items-center">
          <div className={`flex items-center ${isPositivo ? "text-[#21dd74]" : "text-[#d32f2f]"}`}>
            {isPositivo ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-1"
              >
                <path d="m18 15-6-6-6 6" />
              </svg>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-1"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            )}
            <span className="font-medium">
              {formatCurrency(Math.abs(valorizacao))} ({percentualValorizacao.toFixed(2).replace(".", ",")}%)
            </span>
          </div>
        </div>
      </div>

      {/* Informações do Papel */}
      <div className="p-4 border-b border-[#404040] bg-[#2e2e2e]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Informações do Papel</h4>

        <div className="space-y-3">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-[#888] mb-1">Código</div>
              <div className="font-medium">{ativo.cod || "N/A"}</div>
            </div>
            <div>
              <div className="text-xs text-[#888] mb-1">Tipo</div>
              <div className="font-medium">{ativo.typeName || "N/A"}</div>
            </div>
          </div>

          {ativo.isin && (
            <div>
              <div className="text-xs text-[#888] mb-1">ISIN</div>
              <div className="font-medium">{ativo.isin}</div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-[#888] mb-1">Indexador</div>
              <div className="font-medium">{ativo.indexer || "N/A"}</div>
            </div>
            <div>
              <div className="text-xs text-[#888] mb-1">Rating</div>
              <div className="font-medium">{ativo.rating || "N/A"}</div>
            </div>
          </div>

          {ativo.issuer && (
            <div>
              <div className="text-xs text-[#888] mb-1">Emissor</div>
              <div className="font-medium">{ativo.issuer}</div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-4">
            {ativo.expiredDate && (
              <div>
                <div className="text-xs text-[#888] mb-1">Vencimento</div>
                <div className="font-medium">{new Date(ativo.expiredDate).toLocaleDateString("pt-BR")}</div>
              </div>
            )}
            <div>
              <div className="text-xs text-[#888] mb-1">FGC</div>
              <div className="font-medium">{ativo.fgc ? "Sim" : "Não"}</div>
            </div>
          </div>

          {ativo.earlyRedemption !== undefined && (
            <div>
              <div className="text-xs text-[#888] mb-1">Resgate Antecipado</div>
              <div className="font-medium">{ativo.earlyRedemption ? "Sim" : "Não"}</div>
            </div>
          )}
        </div>
      </div>

      {/* Informações da Posição */}
      <div className="p-4 border-b border-[#404040]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Minha Posição</h4>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <div className="text-xs text-[#888] mb-1">Valor Aplicado</div>
            <div className="font-medium">{formatCurrency(ativo.value || 0)}</div>
          </div>
          <div>
            <div className="text-xs text-[#888] mb-1">Valor Atual</div>
            <div className="font-medium">{formatCurrency(ativo.valueUpdated || 0)}</div>
          </div>
        </div>

        {(ativo.qty || ativo.blockedQty) && (
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <div className="text-xs text-[#888] mb-1">Qtd Total</div>
              <div className="font-medium">{(ativo.qty || 0).toLocaleString("pt-BR")}</div>
            </div>
            <div>
              <div className="text-xs text-[#888] mb-1">Qtd Bloqueada</div>
              <div className="font-medium">{(ativo.blockedQty || 0).toLocaleString("pt-BR")}</div>
            </div>
          </div>
        )}

        {(ativo.valueInvestedToday || ativo.valueRedemptionToday) && (
          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-[#888] mb-1">Aplicado Hoje</div>
              <div className="font-medium text-[#21dd74]">+{formatCurrency(ativo.valueInvestedToday || 0)}</div>
            </div>
            <div>
              <div className="text-xs text-[#888] mb-1">Resgatado Hoje</div>
              <div className="font-medium text-[#d32f2f]">-{formatCurrency(ativo.valueRedemptionToday || 0)}</div>
            </div>
          </div>
        )}
      </div>

      {/* Taxas e Preços */}
      {(ativo.performanceFeeMin || ativo.performanceFee || ativo.adminFee) && (
        <div className="p-4 border-b border-[#404040] bg-[#2e2e2e]">
          <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Taxas e Preços</h4>

          <div className="space-y-3">
            {(ativo.performanceFeeMin || ativo.performanceFee) && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-[#888] mb-1">Taxa Aplicação (%)</div>
                  <div className="font-medium">{(ativo.performanceFeeMin || 0).toFixed(2)}%</div>
                </div>
                <div>
                  <div className="text-xs text-[#888] mb-1">Taxa Resgate (%)</div>
                  <div className="font-medium">{(ativo.performanceFee || 0).toFixed(2)}%</div>
                </div>
              </div>
            )}

            {ativo.adminFee && (
              <div>
                <div className="text-xs text-[#888] mb-1">Taxa Administração (%)</div>
                <div className="font-medium">{ativo.adminFee.toFixed(2)}%</div>
              </div>
            )}

            {(ativo.shareValueMin || ativo.shareValueMax) && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-xs text-[#888] mb-1">PU Mínimo</div>
                  <div className="font-medium">{formatCurrency(ativo.shareValueMin || 0)}</div>
                </div>
                <div>
                  <div className="text-xs text-[#888] mb-1">PU Máximo</div>
                  <div className="font-medium">{formatCurrency(ativo.shareValueMax || 0)}</div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </DetalhesBase>
  )
}

"use client"

import { DetalhesBase } from "./detalhes-base"
import { formatCurrency } from "../utils/formatCurrency"

export default function DetalhesFinanceiro({ ativo, isVisible, onClose }) {
  if (!ativo) return null

  const actionButtons = (
    <div className="flex justify-between gap-3">
      <button
        className="bg-[#d32f2f] hover:bg-[#b71c1c] text-white px-4 py-3 rounded-lg font-bold flex-1 transition-colors uppercase text-sm"
        onClick={() => console.log("Sacar")}
      >
        Sacar
      </button>
      <button
        className="bg-[#21dd74] hover:bg-[#1bb85e] text-white px-4 py-3 rounded-lg font-bold flex-1 transition-colors uppercase text-sm"
        onClick={() => console.log("Depositar")}
      >
        Depositar
      </button>
    </div>
  )

  return (
    <DetalhesBase
      isVisible={isVisible}
      onClose={onClose}
      title="Financeiro"
      subtitle="Saldo em Conta"
      actionButtons={actionButtons}
    >
      {/* Saldo */}
      {ativo.value && (
        <div className="p-4 border-b border-[#404040]">
          <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-2">Saldo Disponível</h4>
          <div className="text-2xl font-bold text-[#21dd74]">{formatCurrency(ativo.value)}</div>
        </div>
      )}

      {/* Extrato do Dia */}
      <div className="p-4 border-b border-[#404040]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Extrato do Dia</h4>
        <div className="space-y-2 text-sm">
          {ativo.lancamento && (
            <div className="flex justify-between">
              <span className="text-[#888]">Lançamento:</span>
              <span className="text-white">{ativo.lancamento}</span>
            </div>
          )}
          {ativo.descricao && (
            <div className="flex justify-between">
              <span className="text-[#888]">Descrição:</span>
              <span className="text-white">{ativo.descricao}</span>
            </div>
          )}
          {ativo.liquidacao && (
            <div className="flex justify-between">
              <span className="text-[#888]">Liquidação:</span>
              <span className="text-white">{ativo.liquidacao}</span>
            </div>
          )}
          {ativo.movimentacao && (
            <div className="flex justify-between">
              <span className="text-[#888]">Movimentação:</span>
              <span className="text-white">{ativo.movimentacao}</span>
            </div>
          )}
          {ativo.valorLancamento && (
            <div className="flex justify-between">
              <span className="text-[#888]">Valor:</span>
              <span className="text-white">{formatCurrency(ativo.valorLancamento)}</span>
            </div>
          )}
        </div>
      </div>
    </DetalhesBase>
  )
}

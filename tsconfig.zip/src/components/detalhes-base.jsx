"use client"

import { useState, useEffect } from "react"

export function DetalhesBase({ isVisible, onClose, title, subtitle, children, actionButtons }) {
  console.log("🔍 DetalhesBase renderizado:", { isVisible, title, subtitle })

  const [isAnimating, setIsAnimating] = useState(false)

  useEffect(() => {
    if (isVisible) {
      setIsAnimating(true)
    } else {
      const timer = setTimeout(() => setIsAnimating(false), 300)
      return () => clearTimeout(timer)
    }
  }, [isVisible])

  if (!isVisible && !isAnimating) return null

  return (
    <>
      {/* Modal lateral */}
      <div
        className={`fixed inset-y-0 right-0 w-96 bg-[#2a2a2a] shadow-lg z-50 border-l border-[#404040] transition-transform duration-300 ease-in-out ${
          isVisible ? "translate-x-0" : "translate-x-full"
        }`}
      >
        {/* Cabeçalho */}
        <div className="flex justify-between items-center p-4 border-b border-[#404040] bg-[#353535]">
          <div className="flex-1">
            <h3 className="text-lg font-bold text-white truncate">{title}</h3>
            {subtitle && <p className="text-sm text-[#aaa] truncate">{subtitle}</p>}
          </div>
          <button
            className="bg-[#444] hover:bg-[#555] text-white p-2 rounded-full transition-colors ml-2"
            onClick={onClose}
            title="Fechar detalhes"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <line x1="18" y1="6" x2="6" y2="18"></line>
              <line x1="6" y1="6" x2="18" y2="18"></line>
            </svg>
          </button>
        </div>

        {/* Conteúdo com scroll */}
        <div className="overflow-y-auto h-full pb-24">{children}</div>

        {/* Rodapé com botões de ação */}
        {actionButtons && (
          <div className="absolute bottom-0 left-0 right-0 p-4 bg-[#2a2a2a] border-t border-[#404040]">
            {actionButtons}
          </div>
        )}
      </div>

      {/* Overlay */}
      {(isVisible || isAnimating) && (
        <div
          className={`fixed inset-0 bg-black z-40 transition-opacity duration-300 ${
            isVisible ? "bg-opacity-50" : "bg-opacity-0"
          }`}
          onClick={onClose}
        />
      )}
    </>
  )
}

"use client"

import { useEffect, useRef, useState, useCallback } from "react"
// Importação direta do Recharts
import { PieChart, Pie, Cell, ResponsiveContainer, Sector, Tooltip } from "recharts"

// Importando todos os arquivos de dados
import { patrimonioResumido as patrimonioNivel1 } from "../data/patrimonioResumido"
import { rfPrivadaData } from "../data/dataRFPrivada"
import { fundosData } from "../data/dataFundos"
import { rendaVariavel } from "../data/dataRendaVariavel"
import { dataTesouro  } from "../data/dataTesouro"
import { dataSaldoAttachment } from "../data/dataSaldo"
import { garantiasData } from "../data/dataGarantias"

// Importando funções auxiliares
import { formatCurrency } from "../utils/formatCurrency"

// Importando o contexto
import { usePatrimonio } from "../context/patrimonioContext"
import { rfPublicaData } from "../data/dataRFPublica"

// MAPEAMENTO CORRETO - AGORA COM TODAS AS 7 CATEGORIAS
const patrimonioNivel2 = {
  rendaVariavel: rendaVariavel,
  rfPublica: rfPublicaData, // rfPublica mapeia para tesouroDirectoData
  rfPrivada: rfPrivadaData,
  fundos: fundosData,
  saldoConta: dataSaldoAttachment,
  garantias: garantiasData,
  tesouroDireto: dataTesouro , // Mantendo também este mapeamento
}

// Debug para verificar se temos todas as categorias
console.log("=== VERIFICAÇÃO DAS 7 CATEGORIAS ===")
console.log("patrimonioNivel1 length:", patrimonioNivel1.length)
console.log(
  "Categorias disponíveis:",
  patrimonioNivel1.map((item) => `${item.id}: ${item.label}`),
)
console.log("Dados mapeados:", Object.keys(patrimonioNivel2))

// Função para gerar variações de cor
function generateColorVariation(baseColor, index, total) {
  const r = Number.parseInt(baseColor.slice(1, 3), 16)
  const g = Number.parseInt(baseColor.slice(3, 5), 16)
  const b = Number.parseInt(baseColor.slice(5, 7), 16) 

  const rNorm = r / 255
  const gNorm = g / 255
  const bNorm = b / 255

  const max = Math.max(rNorm, gNorm, bNorm)
  const min = Math.min(rNorm, gNorm, bNorm)

  let h, s
  const l = (max + min) / 2

  if (max === min) {
    h = s = 0
  } else {
    const d = max - min
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min)

    switch (max) {
      case rNorm:
        h = (gNorm - bNorm) / d + (gNorm < bNorm ? 6 : 0)
        break
      case gNorm:
        h = (bNorm - rNorm) / d + 2
        break
      case bNorm:
        h = (rNorm - gNorm) / d + 4
        break
    }

    h /= 6
  }

  const newL = Math.min(0.9, l + (index / total) * 0.5)
  const newS = Math.max(0.3, s - (index / total) * 0.3)

  function hue2rgb(p, q, t) {
    if (t < 0) t += 1
    if (t > 1) t -= 1
    if (t < 1 / 6) return p + (q - p) * 6 * t
    if (t < 1 / 2) return q
    if (t < 2 / 3) return p + (q - p) * (2 / 3 - t) * 6
    return p
  }

  let r1, g1, b1

  if (newS === 0) {
    r1 = g1 = b1 = newL
  } else {
    const q = newL < 0.5 ? newL * (1 + newS) : newL + newS - newL * newS
    const p = 2 * newL - q

    r1 = hue2rgb(p, q, h + 1 / 3)
    g1 = hue2rgb(p, q, h)
    b1 = hue2rgb(p, q, h - 1 / 3)
  }

  const rHex = Math.round(r1 * 255)
    .toString(16)
    .padStart(2, "0")
  const gHex = Math.round(g1 * 255)
    .toString(16)
    .padStart(2, "0")
  const bHex = Math.round(b1 * 255)
    .toString(16)
    .padStart(2, "0")

  return `#${rHex}${gHex}${bHex}`
}

// Função para verificar se um item deve ser excluído do patrimônio total
const isExcludedFromTotal = (item) => {
  if (!item) return false

  const label = item.label ? item.label.toLowerCase() : ""
  const id = item.id ? item.id.toLowerCase() : ""
  const tipo = item.tipo ? item.tipo.toLowerCase() : ""

  // Verificar se contém palavras-chave que indicam exclusão
  const excludedKeywords = ["futuros", "termo", "termos", "aluguel", "aluguer"]

  return excludedKeywords.some((keyword) => label.includes(keyword) || id.includes(keyword) || tipo.includes(keyword))
}

// Função para calcular o total do patrimônio (excluindo Futuros, Termos e Aluguel)
const calcularTotalPatrimonio = () => {
  return patrimonioNivel1.filter((item) => !isExcludedFromTotal(item)).reduce((total, item) => total + item.rawValue, 0)
}

// Função para obter apenas os itens válidos para o patrimônio
// Função para renderizar o texto central
const CenterText = ({ title, value, hideValues }) => {
  return (
    <div
      style={{
        position: "absolute",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        display: "flex",
        flexDirection: "column",
        justifyContent: "center",
        alignItems: "center",
        pointerEvents: "none",
        zIndex: 10,
      }}
    >
      <div
        style={{
          padding: "4px 10px",
          borderRadius: "4px",
          backgroundColor: "rgba(46, 46, 46, 0.7)",
          textAlign: "center",
        }}
      >
        <div style={{ color: "#aaaaaa", fontSize: "12px", marginBottom: "4px" }}>{title}</div>
        <div style={{ color: "#ffffff", fontSize: "16px", fontWeight: "bold" }}>{hideValues ? "••••••" : value}</div>
      </div>
    </div>
  )
}

// Componente para renderizar uma forma ativa personalizada com mais detalhes
const CustomActiveShapePieChart = (props) => {
  const RADIAN = Math.PI / 180
  const {
    cx,
    cy,
    midAngle,
    innerRadius,
    outerRadius,
    startAngle,
    endAngle,
    fill,
    payload,
    percent,
    value,
    category,
    hideValues,
  } = props

  const sin = Math.sin(-RADIAN * midAngle)
  const cos = Math.cos(-RADIAN * midAngle)

  const sx = cx + (outerRadius + 5) * cos
  const sy = cy + (outerRadius + 5) * sin
  const mx = cx + (outerRadius + 30) * cos
  const my = cy + (outerRadius + 30) * sin

  const maxDistance = Math.min(cx * 0.8, 90)
  const textDistance = Math.min(maxDistance, outerRadius + 40)
  const ex = cx + textDistance * cos
  const ey = my

  const textAnchor = cos >= 0 ? "start" : "end"

  return (
    <g>
      <Sector
        cx={cx}
        cy={cy}
        innerRadius={innerRadius}
        outerRadius={outerRadius}
        startAngle={startAngle}
        endAngle={endAngle}
        fill={fill}
      />
      <Sector
        cx={cx}
        cy={cy}
        startAngle={startAngle}
        endAngle={endAngle}
        innerRadius={outerRadius + 3}
        outerRadius={outerRadius + 7}
        fill={fill}
      />
      <path d={`M${sx},${sy}L${mx},${my}L${ex},${ey}`} stroke={fill} fill="none" />
      <circle cx={ex} cy={ey} r={2} fill={fill} stroke="none" />
      <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} textAnchor={textAnchor} fill="#FFF" fontSize={12}>
        {category}
      </text>
      <text x={ex + (cos >= 0 ? 1 : -1) * 12} y={ey} dy={18} textAnchor={textAnchor} fill="#999" fontSize={11}>
        {hideValues ? "••••••" : formatCurrency(value)} ({(percent * 100).toFixed(2)}%)
      </text>
    </g>
  )
}

// Componente para renderizar o tooltip customizado
const CustomTooltip = ({ active, payload, hideValues }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload
    return (
      <div className="bg-[#353535] p-2 rounded shadow-lg border border-[#444] text-white">
        <p className="font-bold">{data.category}</p>
        <p>
          {hideValues ? "••••••" : formatCurrency(data.value)} ({data.percent.toFixed(2)}%)
        </p>
      </div>
    )
  }
  return null
}

// Função para obter o título da categoria selecionada
const getCategoryTitle = (categoryId) => {
  if (!categoryId) return ""

  // Mapeamento direto para evitar problemas
  const titleMap = {
    rendaVariavel: "Renda Variável",
    rfPublica: "Renda Fixa Pública",
    rfPrivada: "Renda Fixa Privada",
    fundos: "Fundos",
    saldoConta: "Saldo em Conta",
    garantias: "Garantias",
    tesouroDireto: "Tesouro Direto",
  }

  return titleMap[categoryId] || categoryId
}

export default function PatrimonioResumido({ type = "light" }) {
  // Estados
  const [openDialog, setOpenDialog] = useState(false)
  const [hiddenSeries, setHiddenSeries] = useState([])
  const [activeIndex, setActiveIndex] = useState(null)
  const [activeDetailIndex, setActiveDetailIndex] = useState(null)
  const [contentHeight, setContentHeight] = useState(0)
  const headerRef = useRef(null)
  const [viewMode, setViewMode] = useState("chart")
  const [classificacao, setClassificacao] = useState("classeAtivo")

  // Usando o contexto compartilhado
  const {
    selectedCategory: contextSelectedCategory,
    setSelectedCategory: contextSetSelectedCategory,
    selectedSubcategory: contextSelectedSubcategory,
    setSelectedSubcategory: contextSetSelectedSubcategory,
    hideValues,
  } = usePatrimonio()

  // Verificar se é versão full
  const isFullVersion = type === "full"

  // Calcular o valor total do patrimônio (excluindo Futuros, Termos e Aluguel)
  const totalPatrimonio = calcularTotalPatrimonio()
  const formattedTotal = formatCurrency(totalPatrimonio)

  // Obter apenas os itens válidos para o gráfico
  // const validPatrimonioItems = getValidPatrimonioItems()
  // const informativeItems = getInformativeItems()

  // Preparar dados para o Recharts (TODOS os itens na legenda normalmente)
  const totalCompleto = patrimonioNivel1.reduce((total, item) => total + item.rawValue, 0)

  const chartData = patrimonioNivel1.map((item) => ({
    category: item.label,
    value: item.rawValue,
    id: item.id,
    color: item.color,
    percent: (item.rawValue / totalCompleto) * 100, // Percentual baseado no total completo
    change: item.change || "+0,0%",
    up: item.up !== undefined ? item.up : true,
    isExcluded: isExcludedFromTotal(item), // Flag para identificar itens excluídos
  }))

  console.log("=== DADOS DO GRÁFICO ===")
  console.log("Total Patrimônio (sem excluídos):", totalPatrimonio)
  console.log("Total Completo (com todos):", totalCompleto)
  console.log("chartData length:", chartData.length)
  console.log(
    "Itens excluídos:",
    chartData.filter((item) => item.isExcluded),
  )

  // Função para obter dados de detalhes
  const getDetailChartData = (categoryId) => {
    console.log("=== getDetailChartData ===")
    console.log("categoryId:", categoryId)

    if (!categoryId) {
      console.error("categoryId é undefined ou null")
      return []
    }

    const categoryData = patrimonioNivel2[categoryId]
    if (!categoryData) {
      console.error(`Dados não encontrados para categoria: ${categoryId}`)
      console.log("Categorias disponíveis:", Object.keys(patrimonioNivel2))
      return []
    }

    console.log(`Dados encontrados para ${categoryId}:`, categoryData)

    if (!categoryData.items || !Array.isArray(categoryData.items) || categoryData.items.length === 0) {
      console.error(`Categoria ${categoryId} não tem itens válidos`)
      return []
    }

    // Filtrar itens de detalhes também (excluir Futuros, Termos, Aluguel)
    const validDetailItems = categoryData.items.filter((item) => !isExcludedFromTotal(item))

    const total = validDetailItems.reduce((sum, item) => sum + (item.rawValue || 0), 0)
    const mainCategory = patrimonioNivel1.find((item) => item.id === categoryId)
    const mainColor = mainCategory ? mainCategory.color : "#00AEEF"

    console.log(`Processando ${validDetailItems.length} itens válidos para ${categoryId}`)

    return validDetailItems.map((item, index) => {
      const itemColor = generateColorVariation(mainColor, index, validDetailItems.length)

      return {
        category: item.label,
        value: item.rawValue || 0,
        id: item.id,
        color: itemColor,
        percent: (item.rawValue / total) * 100,
        change: item.change || "0%",
        up: item.up !== undefined ? item.up : true,
      }
    })
  }

  const detailChartData = contextSelectedCategory ? getDetailChartData(contextSelectedCategory) : []

  // Função para renderizar a legenda do gráfico de detalhes - MOVIDA PARA DENTRO DO COMPONENTE
  const renderizarLegendaDetalhes = () => {
    if (!contextSelectedCategory) return null

    const categoryData = patrimonioNivel2[contextSelectedCategory]
    const categoryTitle = getCategoryTitle(contextSelectedCategory)

    console.log("=== renderizarLegendaDetalhes ===")
    console.log("contextSelectedCategory:", contextSelectedCategory)
    console.log("categoryData:", categoryData)

    if (!categoryData || !categoryData.items || categoryData.items.length === 0) {
      return (
        <div className="bg-[#2e2e2e] text-white h-full flex items-center justify-center min-h-0">
          <div className="text-center p-4 text-[#aaaaaa]">
            <p className="mb-2">
              Dados detalhados para <strong>{categoryTitle}</strong> ainda não estão disponíveis.
            </p>
            <p>Por favor, importe os dados para esta categoria ou selecione outra categoria.</p>
          </div>
        </div>
      )
    }

    // Filtrar itens válidos e informativos
    const validDetailItems = categoryData.items.filter((item) => !isExcludedFromTotal(item))
    const informativeDetailItems = categoryData.items.filter((item) => isExcludedFromTotal(item))

    const mainCategory = patrimonioNivel1.find((item) => item.id === contextSelectedCategory)
    const mainColor = mainCategory ? mainCategory.color : "#00AEEF"

    const validTotal = validDetailItems.reduce((sum, item) => sum + (item.rawValue || 0), 0)

    return (
      <div className="h-full bg-[#2e2e2e] flex flex-col min-h-0">
        <div className="bg-[#2e2e2e] m-2 p-2 rounded-lg flex-1">
          <h3 className="text-sm font-medium text-[#aaaaaa] uppercase mb-2 border-b border-[#404040] pb-1">
            Detalhes: {categoryTitle}
          </h3>
          <div className="overflow-y-auto max-h-[250px]">
            {/* Adicionar opção "Todos" no topo da legenda */}
            <div
              className={`flex items-center justify-between p-1 border-b border-[#404040] cursor-pointer hover:bg-[#3a3a3a] transition-colors transition-all duration-300 relative group ${
                contextSelectedSubcategory === null ? "bg-[#3a3a3a] border-l-4" : ""
              }`}
              style={contextSelectedSubcategory === null ? { borderLeftColor: mainColor } : {}}
              onClick={() => {
                contextSetSelectedSubcategory(null)
                setActiveDetailIndex(null)
              }}
              title="Clique para ver todos os itens"
            >
              <div className="flex items-center gap-2">
                <div className="w-3 h-3 rounded-full" style={{ backgroundColor: mainColor }}></div>
                <div>
                  <div
                    className={`text-sm font-bold group-hover:text-opacity-80`}
                    style={{ color: contextSelectedSubcategory === null ? mainColor : "#ffffff" }}
                  >
                    Todos{" "}
                    <span className="text-xs font-normal" style={{ color: "#aaaaaa" }}>
                      100%
                    </span>
                  </div>
                </div>
              </div>
              <div className="text-xs text-[#aaaaaa] text-right">
                {hideValues ? "••••••" : formatCurrency(validTotal)}
              </div>
            </div>

            {/* Itens válidos da legenda */}
            {validDetailItems.map((item, index) => {
              const itemColor = generateColorVariation(mainColor, index, validDetailItems.length)

              return (
                <div
                  key={index}
                  className={`flex items-center justify-between p-1 border-b border-[#404040] cursor-pointer hover:bg-[#3a3a3a] transition-colors transition-all duration-300 relative group ${
                    contextSelectedSubcategory === item.id ? "bg-[#3a3a3a] border-l-4" : ""
                  }`}
                  style={contextSelectedSubcategory === item.id ? { borderLeftColor: itemColor } : {}}
                  onClick={() => {
                    contextSetSelectedSubcategory(item.id)
                    setActiveDetailIndex(index)
                  }}
                  title="Clique para ver detalhes"
                >
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: itemColor }}></div>
                    <div>
                      <div
                        className={`text-sm font-bold group-hover:text-opacity-80`}
                        style={{ color: contextSelectedSubcategory === item.id ? itemColor : "#ffffff" }}
                      >
                        {item.label}{" "}
                        <span className="text-xs font-normal" style={{ color: "#aaaaaa" }}>
                          {typeof item.percent === "number"
                            ? item.percent.toFixed(2)
                            : ((item.rawValue / validTotal) * 100).toFixed(2)}
                          %
                        </span>
                      </div>
                    </div>
                  </div>
                  <div className="text-xs text-[#aaaaaa] text-right">{hideValues ? "••••••" : item.value}</div>
                </div>
              )
            })}
          </div>
        </div>
      </div>
    )
  }

  // Efeito para calcular a altura disponível para o conteúdo
  useEffect(() => {
    const calculateHeight = () => {
      if (headerRef.current) {
        const headerHeight = headerRef.current.offsetHeight
        const containerHeight = headerRef.current.parentElement.offsetHeight
        setContentHeight(containerHeight - headerHeight)
      }
    }

    calculateHeight()
    window.addEventListener("resize", calculateHeight)
    return () => window.removeEventListener("resize", calculateHeight)
  }, [])

  // Efeito para atualizar o activeIndex quando selectedCategory mudar
  useEffect(() => {
    if (contextSelectedCategory) {
      const index = chartData.findIndex((data) => data.id === contextSelectedCategory)
      setActiveIndex(index >= 0 ? index : null)
    } else {
      setActiveIndex(null)
      contextSetSelectedSubcategory(null)
    }
  }, [contextSelectedCategory, chartData, contextSetSelectedSubcategory])

  // Efeito para atualizar o activeDetailIndex quando selectedSubcategory mudar
  useEffect(() => {
    if (contextSelectedSubcategory && detailChartData.length > 0) {
      const index = detailChartData.findIndex((data) => data.id === contextSelectedSubcategory)
      setActiveDetailIndex(index >= 0 ? index : null)
    } else {
      setActiveDetailIndex(null)
    }
  }, [contextSelectedSubcategory, detailChartData])

  // Função para lidar com o clique na fatia do gráfico
  const handlePieClick = (data, index) => {
    if (!isFullVersion) return

    console.log("=== handlePieClick ===")
    console.log("data:", data)
    console.log("index:", index)

    const newIndex = index === activeIndex ? null : index
    setActiveIndex(newIndex)

    const newCategory = newIndex !== null ? chartData[index].id : null
    console.log("Selecionando categoria:", newCategory)

    contextSetSelectedCategory(newCategory)
  }

  // Função para lidar com o clique na fatia do gráfico de detalhes
  const handleDetailPieClick = useCallback(
    (data, index) => {
      if (!data || index === undefined) return

      console.log("=== handleDetailPieClick ===")
      console.log("data:", data)
      console.log("index:", index)

      setActiveDetailIndex(index === activeDetailIndex ? null : index)

      const newSubcategory = index === activeDetailIndex ? null : detailChartData[index]?.id
      console.log("Selecionando subcategoria:", newSubcategory)

      contextSetSelectedSubcategory(newSubcategory)
    },
    [activeDetailIndex, detailChartData, contextSetSelectedSubcategory],
  )

  // Função para lidar com o clique na legenda
  const handleLegendClick = (item) => {
    if (isFullVersion) {
      console.log("=== handleLegendClick ===")
      console.log("item:", item)

      contextSetSelectedCategory(item.id)
      setActiveIndex(chartData.findIndex((data) => data.id === item.id))
    }
  }

  // Função para alternar visibilidade das séries
  const toggleSeriesVisibility = (index) => {
    if (hiddenSeries.includes(index)) {
      setHiddenSeries(hiddenSeries.filter((i) => i !== index))
    } else {
      setHiddenSeries([...hiddenSeries, index])
    }
  }

  return (
    <div className="bg-[#2a2a2a] text-[#eee] h-full flex flex-col overflow-hidden">
      {/* Cabeçalho com acordeão */}
      <div ref={headerRef} className="sticky top-0 z-[1100] bg-[#2a2a2a]">
        <div className="bg-[#353535]">
          <div className="flex justify-between items-center p-2">
            <div className="flex-1">
              <div>Patrimônio Resumido</div>
              <div className="text-xs text-[#bbb] flex">Últ. Atualização: 17/04/2025 09:26:49</div>
            </div>
          </div>
        </div>
      </div>

      {/* Conteúdo principal */}
      {isFullVersion ? (
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Cards de resumo */}
          <div className="bg-[#2e2e2e] p-2 grid grid-cols-3 gap-2">
            <div className="bg-[#353535] rounded-lg p-2 shadow-md border-l-4 border-[#F7941E] transition-transform hover:scale-[1.02]">
              <div className="flex justify-between items-center">
                <div className="text-xs uppercase text-[#8f8f8f] mb-1">Patrimônio Total</div>
              </div>
              <div className="text-lg font-bold text-white">{hideValues ? "••••••" : formattedTotal}</div>
              <div className="text-xs text-[#aaaaaa]">Excluindo Futuros/Termo e Aluguel</div>
            </div>
            <div className="bg-[#353535] rounded-lg p-2 shadow-md border-l-4 border-[#92278F] transition-transform hover:scale-[1.02]">
              <div className="flex justify-between items-center">
                <div className="text-xs uppercase text-[#8f8f8f] mb-1">Saldo em Conta</div>
              </div>
              <div className="text-lg font-bold text-white">{hideValues ? "••••••" : "R$ 10.000,00"}</div>
              <div className="text-xs text-[#aaaaaa]">10,00% do patrimônio</div>
            </div>
            <div className="bg-[#353535] rounded-lg p-2 shadow-md border-l-4 border-[#00AEEF] transition-transform hover:scale-[1.02]">
              <div className="flex justify-between items-center">
                <div className="text-xs uppercase text-[#8f8f8f] mb-1">Carteira Total</div>
              </div>
              <div className="text-lg font-bold text-white">{hideValues ? "••••••" : "R$ 90.000,00"}</div>
              <div className="text-xs text-[#aaaaaa]">90,00% do patrimônio</div>
            </div>
          </div>

          {/* Versão Full - Gráficos */}
          <div className="flex-1 flex flex-col min-h-0">
            {/* Gráfico principal e legenda */}
            <div className="flex-1 flex flex-row min-h-0">
              <div className="w-1/2 h-full min-h-0">
                {/* Gráfico principal */}
                <div className="relative bg-[#2e2e2e] h-full min-h-0" style={{ position: "relative" }}>
                  <button
                    className="absolute top-2.5 right-2.5 bg-[#444] text-white p-1 rounded-full hover:bg-[#666] transition-colors z-10"
                    onClick={() => setOpenDialog(true)}
                  >
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="16"
                      height="16"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                      strokeLinejoin="round"
                    >
                      <circle cx="12" cy="12" r="10" />
                      <path d="M12 16v-4" />
                      <path d="M12 8h.01" />
                    </svg>
                  </button>
                  <div className="w-full h-full min-h-0">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={chartData.filter((_, index) => !hiddenSeries.includes(index))}
                          cx="50%"
                          cy="50%"
                          innerRadius="60%"
                          outerRadius="85%"
                          dataKey="value"
                          nameKey="category"
                          paddingAngle={1}
                          onClick={handlePieClick}
                          activeIndex={activeIndex}
                          activeShape={(props) => <CustomActiveShapePieChart {...props} hideValues={hideValues} />}
                          cursor="pointer"
                          animationBegin={0}
                          animationDuration={800}
                          animationEasing="ease-out"
                        >
                          {chartData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                          ))}
                        </Pie>
                        <Tooltip content={<CustomTooltip hideValues={hideValues} />} />
                      </PieChart>
                    </ResponsiveContainer>
                    <CenterText title="Total" value={formattedTotal} hideValues={hideValues} />
                  </div>
                </div>
              </div>

              {/* Legenda do gráfico principal */}
              <div className="w-1/2 h-full bg-[#2e2e2e]  min-h-0">
                <div className="bg-[#2e2e2e] m-2 p-2 rounded-lg h-full">
                  <h3 className="text-sm font-medium text-[#aaaaaa] uppercase mb-2 border-b border-[#404040] pb-1">
                    Visão Geral
                  </h3>
                  <div className="overflow-y-auto" style={{ maxHeight: "calc(100% - 60px)" }}>
                    {chartData.map((item, index) => (
                      <div
                        key={index}
                        className={`flex items-center justify-between p-1 border-b border-[#404040] cursor-pointer hover:bg-[#3a3a3a] transition-colors transition-all duration-300 relative group ${
                          contextSelectedCategory === item.id ? "bg-[#3a3a3a] border-l-4" : ""
                        }`}
                        style={contextSelectedCategory === item.id ? { borderLeftColor: item.color } : {}}
                        onClick={() => handleLegendClick(item)}
                        title="Clique para ver detalhes"
                      >
                        <div className="flex items-center gap-2">
                          <div
                            className="w-3 h-3 rounded-full"
                            style={{
                              backgroundColor: item.color,
                            }}
                          ></div>
                          <div>
                            <div
                              className={`text-sm font-bold group-hover:text-opacity-80`}
                              style={{ color: contextSelectedCategory === item.id ? item.color : "#ffffff" }}
                            >
                              {item.category}{" "}
                              <span className="text-xs font-normal" style={{ color: "#aaaaaa" }}>
                                {typeof item.percent === "number" ? item.percent.toFixed(2) : item.percent}%
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="text-xs text-[#aaaaaa] text-right">
                          {hideValues ? "••••••" : formatCurrency(item.value)}
                        </div>
                      </div>
                    ))}

                    {/* Seção informativa para itens excluídos do patrimônio total */}
                    {chartData.filter((item) => item.isExcluded).length > 0 && (
                      <div className="mt-4 p-3 bg-[#353535] rounded-lg border-l-4 border-yellow-500">
                        <h4 className="text-sm font-semibold text-yellow-400 mb-2">
                          ⚠️ Atenção: Itens não inclusos no patrimônio total
                        </h4>
                        <div className="space-y-1">
                          {chartData
                            .filter((item) => item.isExcluded)
                            .map((item, index) => (
                              <div key={`info-${index}`} className="flex justify-between items-center text-xs">
                                <span className="text-[#aaa]">{item.category}:</span>
                                <span className="text-yellow-400">
                                  {hideValues ? "••••••" : formatCurrency(item.value)}
                                </span>
                              </div>
                            ))}
                        </div>
                        <p className="text-xs text-[#888] mt-2">
                          * Os itens acima são exibidos na legenda mas NÃO são somados ao patrimônio total
                        </p>
                      </div>
                    )}

                    {/* Adicionar o patrimônio total ao final da legenda APENAS na legenda 1 */}
                    <div
                      style={{
                        display: "flex",
                        alignItems: "center",
                        marginTop: "10px",
                        borderTop: "1px solid #444",
                        paddingTop: "10px",
                      }}
                    >
                      <div
                        style={{
                          width: "12px",
                          height: "12px",
                          background: "linear-gradient(45deg, #F7941E, #2196F3)",
                          marginRight: "8px",
                          borderRadius: "2px",
                        }}
                      ></div>
                      <strong style={{ color: "#ffffff", fontSize: "14px" }}>
                        Patrimônio Total: {hideValues ? "••••••" : formattedTotal}
                      </strong>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* Gráfico de detalhes ou instrução */}
            <div className="flex-1 flex flex-row min-h-0">
              {contextSelectedCategory && detailChartData.length > 0 ? (
                <>
                  <div className="w-1/2 h-full bg-[#2e2e2e] min-h-0" style={{ position: "relative" }}>
                    {/* Gráfico de detalhes */}
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={detailChartData}
                          cx="50%"
                          cy="50%"
                          innerRadius="60%"
                          outerRadius="85%"
                          dataKey="value"
                          nameKey="category"
                          paddingAngle={1}
                          onClick={handleDetailPieClick}
                          activeIndex={activeDetailIndex}
                          activeShape={(props) => <CustomActiveShapePieChart {...props} hideValues={hideValues} />}
                          cursor="pointer"
                          animationBegin={0}
                          animationDuration={800}
                          animationEasing="ease-out"
                        >
                          {detailChartData.map((entry, index) => (
                            <Cell key={`cell-detail-${index}`} fill={entry.color} stroke="none" />
                          ))}
                        </Pie>
                        <Tooltip content={<CustomTooltip hideValues={hideValues} />} />
                      </PieChart>
                    </ResponsiveContainer>
                    <CenterText
                      title={getCategoryTitle(contextSelectedCategory)}
                      value={formatCurrency(detailChartData.reduce((sum, item) => sum + item.value, 0))}
                      hideValues={hideValues}
                    />
                  </div>

                  {/* Legenda do gráfico de detalhes */}
                  <div className="w-1/2 h-full min-h-0">{renderizarLegendaDetalhes()}</div>
                </>
              ) : contextSelectedCategory ? (
                <div className="w-full h-full bg-[#2e2e2e] flex items-center justify-center text-center text-sm text-[#aaa] min-h-0">
                  <div>
                    <p>Carregando dados para {getCategoryTitle(contextSelectedCategory)}...</p>
                    <p className="text-xs mt-2">
                      Categoria: {contextSelectedCategory} | Dados disponíveis: {detailChartData.length}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="w-full h-full bg-[#2e2e2e] flex items-center justify-center text-center text-sm text-[#aaa] min-h-0">
                  <p>Clique em uma categoria no gráfico ou na legenda acima para ver detalhes</p>
                </div>
              )}
            </div>
          </div>
        </div>
      ) : (
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Versão Light (original) */}
          {/* Gráfico */}
          <div className="relative bg-[#2e2e2e] h-2/3">
            <button
              className="absolute top-2.5 right-2.5 bg-[#444] text-white p-1 rounded-full hover:bg-[#666] transition-colors z-10"
              onClick={() => setOpenDialog(true)}
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
              >
                <circle cx="12" cy="12" r="10" />
                <path d="M12 16v-4" />
                <path d="M12 8h.01" />
              </svg>
            </button>

            {/* Container do gráfico Recharts */}
            <div className="w-full h-full">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={chartData.filter((_, index) => !hiddenSeries.includes(index))}
                    cx="50%"
                    cy="50%"
                    innerRadius="60%"
                    outerRadius="85%"
                    dataKey="value"
                    nameKey="category"
                    paddingAngle={1}
                    animationBegin={0}
                    animationDuration={800}
                    animationEasing="ease-out"
                  >
                    {chartData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} stroke="none" />
                    ))}
                  </Pie>
                  <Tooltip content={<CustomTooltip hideValues={hideValues} />} />
                </PieChart>
              </ResponsiveContainer>
              <CenterText title="Total" value={formattedTotal} hideValues={hideValues} />
            </div>
          </div>

          {/* Botões de ação */}
          <div className="bg-[#2e2e2e] p-1">
            <div className="flex gap-2 items-center justify-center">
              <button className="uppercase bg-[#058CE1] hover:bg-[#006FB5] text-white font-bold py-1 rounded w-[125px] text-center cursor-pointer transition-colors">
                Comprar
              </button>
              <button className="uppercase bg-[#FDAA1A] hover:bg-[#F09800] text-white font-bold py-1 rounded w-[125px] text-center cursor-pointer transition-colors">
                Vender
              </button>
            </div>
          </div>

          {/* Legenda externa - Versão Light */}
          <div className="bg-[#2e2e2e] p-2 text-white h-1/3 overflow-y-auto">
            <div className="bg-[#2e2e2e] m-2 p-2 rounded-lg">
              <h3 className="text-sm font-medium text-[#aaaaaa] uppercase mb-2 border-b border-[#404040] pb-1">
                Visão Geral ({chartData.length} categorias)
              </h3>
              {chartData.map((item, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-1 border-b border-[#404040] cursor-pointer hover:bg-[#3a3a3a] transition-colors"
                  onClick={() => toggleSeriesVisibility(index)}
                >
                  <div
                    className="w-2.5 h-2.5 rounded-full"
                    style={{ backgroundColor: item.color, opacity: hiddenSeries.includes(index) ? 0.5 : 1 }}
                  ></div>
                  <div className="flex-1">
                    <div className="text-sm font-bold">
                      {typeof item.percent === "number" ? item.percent.toFixed(2) : item.percent}% {item.category}
                    </div>
                  </div>
                  <div className="text-xs text-[#aaaaaa]">{hideValues ? "••••••" : formatCurrency(item.value)}</div>
                </div>
              ))}

              {/* Seção informativa para itens excluídos do patrimônio total */}
              {chartData.filter((item) => item.isExcluded).length > 0 && (
                <div className="mt-4 p-3 bg-[#353535] rounded-lg border-l-4 border-yellow-500">
                  <h4 className="text-sm font-semibold text-yellow-400 mb-2">
                    ⚠️ Atenção: Itens não inclusos no patrimônio total
                  </h4>
                  <div className="space-y-1">
                    {chartData
                      .filter((item) => item.isExcluded)
                      .map((item, index) => (
                        <div key={`info-${index}`} className="flex justify-between items-center text-xs">
                          <span className="text-[#aaa]">{item.category}:</span>
                          <span className="text-yellow-400">{hideValues ? "••••••" : formatCurrency(item.value)}</span>
                        </div>
                      ))}
                  </div>
                  <p className="text-xs text-[#888] mt-2">
                    * Os itens acima são exibidos na legenda mas NÃO são somados ao patrimônio total
                  </p>
                </div>
              )}

              {/* Adicionar o patrimônio total ao final da legenda APENAS na versão light */}
              <div
                style={{
                  display: "flex",
                  alignItems: "center",
                  marginTop: "10px",
                  borderTop: "1px solid #444",
                  paddingTop: "10px",
                }}
              >
                <div
                  style={{
                    width: "10px",
                    height: "10px",
                    background: "linear-gradient(45deg, #F7941E, #2196F3)",
                    marginRight: "8px",
                    borderRadius: "2px",
                  }}
                ></div>
                <strong style={{ color: "#ffffff", fontSize: "14px" }}>
                  Patrimônio Total: {hideValues ? "••••••" : formattedTotal}
                </strong>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dialog de informações */}
      {openDialog && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-[#2a2a2a] text-white p-4 rounded max-w-md">
            <p>
              Este gráfico representa a distribuição percentual da sua carteira.
              <br />O valor total também está exibido no centro.
              {isFullVersion && (
                <>
                  <br />
                  <br />
                  Na versão completa, você pode clicar em uma categoria no gráfico ou na legenda para ver detalhes da
                  sua composição.
                </>
              )}
              <br />
              <br />
              <strong>Nota:</strong> Ativos do tipo "Futuros", "Termos" e "Aluguel" não são incluídos no cálculo do
              patrimônio total, sendo exibidos apenas como informação adicional.
            </p>
            <div className="flex justify-end mt-4">
              <button
                className="bg-[#444] hover:bg-[#666] text-white px-4 py-2 rounded transition-colors"
                onClick={() => setOpenDialog(false)}
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

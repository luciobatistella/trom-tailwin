"use client"

import { useState } from "react"
import { formatCurrency } from "../utils/formatCurrency"

// Component for rendering position badge
const PosicaoBadge = ({ value, hideValues }) => {
  if (hideValues) return "••••••"

  const numValue = typeof value === "number" ? value : Number.parseFloat(value) || 0
  const isPositive = numValue >= 0
  const formattedValue = `${numValue.toLocaleString("pt-BR", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}%`

  return (
    <span
      className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium ${
        isPositive
          ? "bg-green-100 text-green-800 border border-green-200"
          : "bg-red-100 text-red-800 border border-red-200"
      }`}
    >
      {isPositive ? "+" : ""}
      {formattedValue}
    </span>
  )
}

// Loading skeletons
const MyAssetsHeaderSkeleton = () => (
  <div className="mt-6 animate-pulse">
    <div className="h-6 bg-[#404040] rounded w-1/3 mb-3" />
  </div>
)

const NoAssetsMessageSkeleton = () => (
  <div className="mt-6 text-center p-4 border border-[#404040] rounded animate-pulse">
    <div className="h-4 bg-[#404040] rounded mx-auto w-3/4" />
  </div>
)

const TableRowSkeleton = ({ columns }) => (
  <tr className="border-b border-[#404040] animate-pulse">
    {columns.map((_, index) => (
      <td key={index} className="py-2 px-3">
        <div className="h-4 bg-[#404040] rounded w-full" />
      </td>
    ))}
  </tr>
)

const TableHeaderSkeleton = ({ columns }) => (
  <thead>
    <tr className="border-b border-[#404040]">
      {columns.map((_, index) => (
        <th key={index} className="py-2 px-3">
          <div className="h-3 bg-[#404040] rounded w-full animate-pulse" />
        </th>
      ))}
    </tr>
  </thead>
)

const AssetsTableSkeleton = ({ title, columnCount = 7, rowCount = 5 }) => (
  <div className="mt-6 animate-pulse">
    <div className="h-6 bg-[#404040] rounded w-1/3 mb-3" />
    <div className="overflow-x-auto">
      <table className="min-w-full">
        <TableHeaderSkeleton columns={Array(columnCount).fill(null)} />
        <tbody>
          {Array(rowCount)
            .fill(null)
            .map((_, index) => (
              <TableRowSkeleton key={index} columns={Array(columnCount).fill(null)} />
            ))}
        </tbody>
      </table>
    </div>
  </div>
)

export default function MeusAtivosGrid({
  categoryData,
  contextSelectedCategory,
  contextSelectedSubcategory,
  hideValues,
  isLoadingAssetsHeader,
  isLoadingAssetsTable,
  isLoadingNoAssetsMessage,
  selectedAtivo,
  handleAtivoClick,
}) {
  // Estados para controlar a ordenação
  const [sortConfig, setSortConfig] = useState({
    key: null,
    direction: "ascending",
  })

  // Função para ordenar os dados da tabela
  const sortedData = (data) => {
    if (!sortConfig.key) return data

    return [...data].sort((a, b) => {
      if (a[sortConfig.key] === undefined || b[sortConfig.key] === undefined) {
        return 0
      }

      let aValue = a[sortConfig.key]
      let bValue = b[sortConfig.key]

      if (typeof aValue === "string" && !isNaN(aValue.replace(/[^\d.-]/g, ""))) {
        aValue = Number.parseFloat(aValue.replace(/[^\d.-]/g, "").replace(",", "."))
      }
      if (typeof bValue === "string" && !isNaN(bValue.replace(/[^\d.-]/g, ""))) {
        bValue = Number.parseFloat(bValue.replace(/[^\d.-]/g, "").replace(",", "."))
      }

      if (aValue < bValue) {
        return sortConfig.direction === "ascending" ? -1 : 1
      }
      if (aValue > bValue) {
        return sortConfig.direction === "ascending" ? 1 : -1
      }
      return 0
    })
  }

  // Função para lidar com o clique nas colunas
  const requestSort = (key) => {
    let direction = "ascending"
    if (sortConfig.key === key && sortConfig.direction === "ascending") {
      direction = "descending"
    }
    setSortConfig({ key, direction })
  }

  // Se não temos categoria selecionada, não mostrar nada
  if (!contextSelectedCategory || !categoryData) {
    return null
  }

  // Se não temos subcategoria selecionada, mostrar todos os ativos da categoria
  if (!contextSelectedSubcategory) {
    // Coletar todos os ativos de todas as subcategorias
    const todosAtivos = []
    categoryData.items.forEach((item) => {
      if (item.ativos && item.ativos.length > 0) {
        todosAtivos.push(
          ...item.ativos.map((ativo) => ({
            ...ativo,
            subcategoria: item.label,
          })),
        )
      }
    })

    if (todosAtivos.length === 0) {
      if (isLoadingNoAssetsMessage) {
        return <NoAssetsMessageSkeleton />
      }

      return (
        <div className="mt-6 text-center p-4 text-[#aaaaaa] border border-[#404040] rounded">
          Não há ativos detalhados disponíveis para {categoryData.title || contextSelectedCategory}.
        </div>
      )
    }

    // Colunas padrão para todos os ativos
    const colunas = [
      { id: "codigo", label: "Código", align: "left" },
      { id: "nome", label: "Nome", align: "left" },
      { id: "subcategoria", label: "Subcategoria", align: "left" },
      { id: "quantidade", label: "Qtde", align: "right", format: (value) => value?.toLocaleString("pt-BR") },
      { id: "valorAtual", label: "Valor Atual", align: "right", format: (value) => formatCurrency(value) },
    ]

    if (isLoadingAssetsTable) {
      return <AssetsTableSkeleton title="Todos os ativos" columnCount={5} rowCount={8} />
    }

    return (
      <div className="mt-6 pb-8">
        {isLoadingAssetsHeader ? (
          <MyAssetsHeaderSkeleton />
        ) : (
          <h3 className="text-lg font-bold mb-3">
            Todos meus ativos de {categoryData.title || contextSelectedCategory}
          </h3>
        )}
        <div className="overflow-x-auto">
          <table className="min-w-full">
            <thead>
              <tr className="border-b border-[#404040]">
                {colunas.map((coluna) => (
                  <th
                    key={coluna.id}
                    className={`py-2 px-3 text-${coluna.align} text-xs font-medium text-[#aaaaaa] uppercase tracking-wider cursor-pointer hover:bg-[#3a3a3a]`}
                    onClick={() => requestSort(coluna.id)}
                  >
                    <div className="flex items-center justify-between">
                      <span>{coluna.label}</span>
                      {sortConfig.key === coluna.id && (
                        <span className="ml-1">{sortConfig.direction === "ascending" ? "↑" : "↓"}</span>
                      )}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {sortedData(todosAtivos).map((ativo, index) => (
                <tr
                  key={index}
                  className={`border-b border-[#404040] hover:bg-[#3a3a3a] cursor-pointer ${
                    selectedAtivo === ativo ? "bg-[#3a3a3a]" : ""
                  }`}
                  onClick={() => handleAtivoClick(ativo)}
                >
                  {colunas.map((coluna) => (
                    <td key={coluna.id} className={`py-2 px-3 text-${coluna.align} whitespace-nowrap`}>
                      {coluna.format && ativo[coluna.id] !== undefined
                        ? hideValues && coluna.id !== "codigo" && coluna.id !== "nome" && coluna.id !== "subcategoria"
                          ? "••••••"
                          : coluna.format(ativo[coluna.id])
                        : hideValues && coluna.id !== "codigo" && coluna.id !== "nome" && coluna.id !== "subcategoria"
                          ? "••••••"
                          : ativo[coluna.id] || "-"}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
            <tfoot>
              <tr className="bg-[#353535] border-t-2 border-[#555]">
                <td colSpan={colunas.length - 1} className="py-3 px-3 font-bold text-white">
                  Total Geral
                </td>
                <td className="py-3 px-3 text-right font-bold text-white">
                  {hideValues
                    ? "••••••"
                    : formatCurrency(todosAtivos.reduce((total, ativo) => total + (ativo.valorAtual || 0), 0))}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>
      </div>
    )
  }

  // Código para quando uma subcategoria está selecionada
  const subcategoryData = categoryData.items.find((item) => item.id === contextSelectedSubcategory)
  if (!subcategoryData) {
    return null
  }

  const ativosData = subcategoryData.ativos
  if (!ativosData || ativosData.length === 0) {
    if (isLoadingNoAssetsMessage) {
      return <NoAssetsMessageSkeleton />
    }

    return (
      <div className="mt-6 text-center p-4 text-[#aaaaaa] border border-[#404040] rounded">
        Não há ativos detalhados disponíveis para {subcategoryData.label}.
      </div>
    )
  }

  // Determinar quais colunas mostrar com base na subcategoria
  let colunas = []
  let columnCount = 4

  // Colunas específicas para cada tipo de subcategoria
  if (contextSelectedSubcategory === "aVistaFracionario") {
    columnCount = 7
    colunas = [
      { id: "codigo", label: "Código", align: "left" },
      { id: "nome", label: "Nome", align: "left" },
      { id: "quantidade", label: "Qtde", align: "right", format: (value) => value.toLocaleString("pt-BR") },
      {
        id: "precoMedio",
        label: "Preço Médio",
        align: "right",
        format: (value) => value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }),
      },
      {
        id: "cotacaoAtual",
        label: "Cotação Atual",
        align: "right",
        format: (value) => value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" }),
      },
      {
        id: "posicao",
        label: "Posição %",
        align: "right",
        format: (value) => <PosicaoBadge value={value} hideValues={hideValues} />,
      },
      { id: "valorAtual", label: "Valor Atual", align: "right", format: (value) => formatCurrency(value) },
    ]
  } else {
    // Colunas padrão para outras subcategorias
    columnCount = 4
    colunas = [
      { id: "codigo", label: "Código", align: "left" },
      { id: "nome", label: "Nome", align: "left" },
      { id: "quantidade", label: "Qtde", align: "right", format: (value) => value?.toLocaleString("pt-BR") },
      { id: "valorAtual", label: "Valor Atual", align: "right", format: (value) => formatCurrency(value) },
    ]
  }

  if (isLoadingAssetsTable) {
    return (
      <AssetsTableSkeleton title={`Meus Ativos de ${subcategoryData.label}`} columnCount={columnCount} rowCount={6} />
    )
  }

  return (
    <div className="mt-6 pb-8">
      {isLoadingAssetsHeader ? (
        <MyAssetsHeaderSkeleton />
      ) : (
        <h3 className="text-lg font-bold mb-3">Meus Ativos de {subcategoryData.label}</h3>
      )}
      <div className="overflow-x-auto">
        <table className="min-w-full">
          <thead>
            <tr className="border-b border-[#404040]">
              {colunas.map((coluna) => (
                <th
                  key={coluna.id}
                  className={`py-2 px-3 text-${coluna.align} text-xs font-medium text-[#aaaaaa] uppercase tracking-wider cursor-pointer hover:bg-[#3a3a3a]`}
                  onClick={() => requestSort(coluna.id)}
                >
                  <div className="flex items-center justify-between">
                    <span>{coluna.label}</span>
                    {sortConfig.key === coluna.id && (
                      <span className="ml-1">{sortConfig.direction === "ascending" ? "↑" : "↓"}</span>
                    )}
                  </div>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedData(ativosData).map((ativo, index) => (
              <tr
                key={index}
                className={`border-b border-[#404040] hover:bg-[#3a3a3a] cursor-pointer ${
                  selectedAtivo === ativo ? "bg-[#3a3a3a]" : ""
                }`}
                onClick={() => handleAtivoClick(ativo)}
              >
                {colunas.map((coluna) => (
                  <td key={coluna.id} className={`py-2 px-3 text-${coluna.align} whitespace-nowrap`}>
                    {coluna.format && ativo[coluna.id] !== undefined
                      ? typeof coluna.format(ativo[coluna.id]) === "object"
                        ? coluna.format(ativo[coluna.id])
                        : hideValues && coluna.id !== "codigo" && coluna.id !== "nome" && coluna.id !== "subcategoria"
                          ? "••••••"
                          : coluna.format(ativo[coluna.id])
                      : hideValues && coluna.id !== "codigo" && coluna.id !== "nome" && coluna.id !== "subcategoria"
                        ? "••••••"
                        : ativo[coluna.id] || "-"}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
          <tfoot>
            <tr className="bg-[#353535] border-t-2 border-[#555]">
              <td colSpan={colunas.length - 1} className="py-3 px-3 font-bold text-white">
                Total da Subcategoria
              </td>
              <td className="py-3 px-3 text-right font-bold text-white">
                {hideValues
                  ? "••••••"
                  : formatCurrency(ativosData.reduce((total, ativo) => total + (ativo.valorAtual || 0), 0))}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  )
}

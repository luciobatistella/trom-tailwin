"use client"

import { useState } from "react"
import { DetalhesBase } from "./detalhes-base"
import { formatCurrency } from "../utils/formatCurrency"

export default function DetalhesRendaVariavel({ ativo, codigo, isVisible, onClose }) {
  const [tab, setTab] = useState(0) // 0 = Provisionados, 1 = Pagos
  const [openItems, setOpenItems] = useState({})
  const [showFilters, setShowFilters] = useState(false)

  if (!ativo) return null

  // Dados de cotação
  const valorAtual = ativo.valorAtual || 0
  const precoMedio = ativo.precoMedio || 0
  const quantidade = ativo.quantidade || 0
  const posicao = ativo.posicao || 0
  const isPositivo = posicao >= 0
  const valorizacaoReais = valorAtual - precoMedio * quantidade
  const dataAtual = new Date()
  const horaFormatada = dataAtual.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  })

  // Botões de ação
  const actionButtons = (
    <div className="flex justify-between gap-2">
      <button
        className="bg-[#d32f2f] hover:bg-[#b71c1c] text-white px-3 py-2 rounded-lg font-bold flex-1 transition-colors uppercase text-xs"
        onClick={() => console.log("Vender", codigo)}
      >
        Vender
      </button>
      <button
        className="bg-[#21dd74] hover:bg-[#1bb85e] text-white px-3 py-2 rounded-lg font-bold flex-1 transition-colors uppercase text-xs"
        onClick={() => console.log("Comprar", codigo)}
      >
        Comprar
      </button>
    </div>
  )

  const toggleItem = (id) =>
    setOpenItems((prev) => ({ ...prev, [id]: !prev[id] }))
  const horaAtualizacao = dataAtual.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  })

  return (
    <DetalhesBase
      isVisible={isVisible}
      onClose={onClose}
      title={codigo || "Ação"}
      subtitle={ativo.nome}
      actionButtons={actionButtons}
    >
      {/* Cotação em Tempo Real */}
      <div className="p-4 border-b border-[#404040]">
        <div className="flex justify-between items-center mb-2">
          <h4 className="text-sm font-semibold text-[#aaa] uppercase">Última Cotação</h4>
          <div className="text-xs text-[#888]">Atualizado às {horaFormatada}</div>
        </div>
        <div className="text-2xl font-bold text-white mb-2">
          {formatCurrency(ativo.cotacaoAtual || 0)}
        </div>
        <div className="flex items-center justify-between">
          <div className={`flex items-center ${isPositivo ? "text-[#21dd74]" : "text-[#d32f2f]"}`}>
            {ativo.indicacaoAlta ? (
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 mr-1" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m18 15-6-6-6 6" />
              </svg>
            ) : (
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4 mr-1" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="m6 9 6 6 6-6" />
              </svg>
            )}
            <span className="font-medium">
              {formatCurrency(Math.abs(valorizacaoReais))} ({posicao.toFixed(2).replace('.', ',')}%)
            </span>
          </div>
          <span className="text-xs text-[#888]">no dia</span>
        </div>
      </div>

      {/* === Proventos === */}
      <div className="text-[#eee]">
        {/* Header com filtros e atualização */}
        <div className="p-2 pl-2 h-[68px] flex items-center justify-between">
          <div className="font-semibold">Proventos</div>
          {/* <div className="flex items-center gap-3">
            <button onClick={() => setShowFilters((prev) => !prev)} className="p-1 text-white hover:text-[#F7941E]">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3" />
              </svg>
            </button>
            <button onClick={() => window.location.reload()} className="p-1 text-white hover:text-[#21dd74]">
              <svg xmlns="http://www.w3.org/2000/svg" className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <path d="M21 12a9 9 0 0 1-9 9c-4.97 0-9-4.03-9-9s4.03-9 9-9h3" />
                <path d="M15 3l3 3-3 3" />
              </svg>
            </button>
          </div> */}
        </div>
        <div className="border-b border-[#1C1C1C]" />

        {/* Painel de filtros */}
        {showFilters && (
          <div className="bg-[#1e1e1e] p-2 flex gap-2">
            <input
              type="text"
              placeholder="Buscar ativo..."
              className="w-full px-3 py-1 text-sm bg-[#333] text-[#eee] rounded focus:outline-none"
            />
            <input
              type="date"
              className="px-3 py-1 text-sm bg-[#333] text-[#eee] rounded focus:outline-none"
            />
          </div>
        )}

        {/* Tabs */}
        <div className="flex border-b border-[#444]">
          <button
            className={`px-4 py-2 text-sm ${
              tab === 0
                ? "text-[#F7941E] border-b-2 border-[#F7941E] -mb-[1px]"
                : "text-[#aaa] hover:text-white"
            }`}
            onClick={() => setTab(0)}
          >
            Provisionados
          </button>
          <button
            className={`px-4 py-2 text-sm ${
              tab === 1
                ? "text-[#F7941E] border-b-2 border-[#F7941E] -mb-[1px]"
                : "text-[#aaa] hover:text-white"
            }`}
            onClick={() => setTab(1)}
          >
            Pagos
          </button>
        </div>

        {/* Timeline */}
        <div className="relative px-4 py-4">
          {(tab === 0 ? ativo.proventosProvisionados : ativo.proventosPagos || [])
            .map((item, index, arr) => (
              <div key={item.id ?? index} className="flex items-start mb-6">
                <div className="relative flex flex-col items-center mr-3">
                  <div className="w-2.5 h-2.5 bg-[#F7941E] rounded-full mt-1"></div>
                  {index < arr.length - 1 && (
                    <div className="absolute top-3 bottom-0 w-[1px] bg-[#555]"></div>
                  )}
                </div>
                <div className="flex-1 bg-[#333] rounded p-3">
                  <div className="flex justify-between cursor-pointer" onClick={() => toggleItem(item.id ?? index)}>
                    <div>
                      <div className="text-xs text-[#bbb]">{item.paymentDate}</div>
                      <div className="text-sm text-white">
                        {item.dist ?? item.bonusDescription} — {codigo}
                      </div>
                    </div>
                    <div className="flex items-center gap-1">
                      <div className="text-sm text-[#21dd74] font-bold">
                        {formatCurrency(item.value || 0)}
                      </div>
                      <svg xmlns="http://www.w3.org/2000/svg" className={`w-4 h-4 text-[#ccc] transition-transform ${openItems[item.id ?? index] ? "rotate-180" : ""}`} fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m6 9 6 6 6-6" />
                      </svg>
                    </div>
                  </div>
                  <div className={`mt-2 transition-all duration-300 overflow-hidden ${openItems[item.id ?? index] ? "max-h-[200px] opacity-100" : "max-h-0 opacity-0"}`}>
                    <div className="text-xs text-[#eee] space-y-1">
                      <div className="flex justify-between"><span>Quantidade:</span><span>{item.qty}</span></div>
                      <div className="flex justify-between"><span>Valor Bruto:</span><span>{formatCurrency(item.inclusiveValue)}</span></div>
                      <div className="flex justify-between"><span>IR:</span><span>{formatCurrency(item.ir)}</span></div>
                      <div className="flex justify-between"><span>Valor Líquido:</span><span>{formatCurrency(item.value)}</span></div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
        </div>
      </div>
      {/* === Fim Proventos === */}
    </DetalhesBase>
  )
}

"use client"

import { DetalhesBase } from "./detalhes-base"
import { formatCurrency } from "../utils/formatCurrency"

export default function DetalhesFundosClubes({ ativo, isVisible, onClose }) {
  if (!ativo) return null

  const actionButtons = (
    <div className="flex justify-between gap-3">
      <button
        className="bg-[#d32f2f] hover:bg-[#b71c1c] text-white px-4 py-3 rounded-lg font-bold flex-1 transition-colors uppercase text-sm"
        onClick={() => console.log("Resgatar")}
      >
        Resgatar
      </button>
      <button
        className="bg-[#21dd74] hover:bg-[#1bb85e] text-white px-4 py-3 rounded-lg font-bold flex-1 transition-colors uppercase text-sm"
        onClick={() => console.log("Aplicar")}
      >
        Aplicar
      </button>
    </div>
  )

  return (
    <DetalhesBase
      isVisible={isVisible}
      onClose={onClose}
      title="Fundos e Clubes"
      subtitle={ativo.bond || ativo.description || "Fundo"}
      actionButtons={actionButtons}
    >
      {/* Informações do Fundo */}
      <div className="p-4 border-b border-[#404040]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Informações do Fundo</h4>
        <div className="space-y-2 text-sm">
          {ativo.classification && (
            <div className="flex justify-between">
              <span className="text-[#888]">Classificação:</span>
              <span className="text-white">{ativo.classification}</span>
            </div>
          )}
          {ativo.category && (
            <div className="flex justify-between">
              <span className="text-[#888]">Categoria:</span>
              <span className="text-white">{ativo.category}</span>
            </div>
          )}
          {ativo.strategy && (
            <div className="flex justify-between">
              <span className="text-[#888]">Estratégia:</span>
              <span className="text-white">{ativo.strategy}</span>
            </div>
          )}
          {ativo.manager && (
            <div className="flex justify-between">
              <span className="text-[#888]">Gestor:</span>
              <span className="text-white">{ativo.manager}</span>
            </div>
          )}
          {ativo.administrator && (
            <div className="flex justify-between">
              <span className="text-[#888]">Administrador:</span>
              <span className="text-white">{ativo.administrator}</span>
            </div>
          )}
        </div>
      </div>

      {/* Cota */}
      <div className="p-4 border-b border-[#404040]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Cota</h4>
        <div className="space-y-2 text-sm">
          {ativo.quoteValue && (
            <div className="flex justify-between">
              <span className="text-[#888]">Valor da Cota:</span>
              <span className="text-white">{formatCurrency(ativo.quoteValue)}</span>
            </div>
          )}
          {ativo.quoteValueDate && (
            <div className="flex justify-between">
              <span className="text-[#888]">Data da Cota:</span>
              <span className="text-white">{ativo.quoteValueDate}</span>
            </div>
          )}
          {ativo.adminFee && (
            <div className="flex justify-between">
              <span className="text-[#888]">Taxa Adm:</span>
              <span className="text-white">{ativo.adminFee}%</span>
            </div>
          )}
          {ativo.benchmark && (
            <div className="flex justify-between">
              <span className="text-[#888]">Benchmark:</span>
              <span className="text-white">{ativo.benchmark}</span>
            </div>
          )}
        </div>
      </div>

      {/* Performance */}
      <div className="p-4 border-b border-[#404040]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Performance</h4>
        <div className="space-y-2 text-sm">
          {ativo.performance_month && (
            <div className="flex justify-between">
              <span className="text-[#888]">No Mês:</span>
              <span className="text-white">{ativo.performance_month}%</span>
            </div>
          )}
          {ativo.performance_year && (
            <div className="flex justify-between">
              <span className="text-[#888]">No Ano:</span>
              <span className="text-white">{ativo.performance_year}%</span>
            </div>
          )}
          {ativo.performance_last12m && (
            <div className="flex justify-between">
              <span className="text-[#888]">12 Meses:</span>
              <span className="text-white">{ativo.performance_last12m}%</span>
            </div>
          )}
        </div>
      </div>

      {/* Posição */}
      <div className="p-4 border-b border-[#404040]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Posição</h4>
        <div className="space-y-2 text-sm">
          {ativo.qtyQuote && (
            <div className="flex justify-between">
              <span className="text-[#888]">Qtd Cotas:</span>
              <span className="text-white">{ativo.qtyQuote}</span>
            </div>
          )}
          {ativo.valueInvested && (
            <div className="flex justify-between">
              <span className="text-[#888]">Valor Investido:</span>
              <span className="text-white">{formatCurrency(ativo.valueInvested)}</span>
            </div>
          )}
          {ativo.valueTotal && (
            <div className="flex justify-between">
              <span className="text-[#888]">Valor Total:</span>
              <span className="text-white">{formatCurrency(ativo.valueTotal)}</span>
            </div>
          )}
          {ativo.valueNet && (
            <div className="flex justify-between">
              <span className="text-[#888]">Valor Líquido:</span>
              <span className="text-white">{formatCurrency(ativo.valueNet)}</span>
            </div>
          )}
        </div>
      </div>
    </DetalhesBase>
  )
}

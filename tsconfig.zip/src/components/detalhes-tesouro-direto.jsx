"use client"

import { DetalhesBase } from "./detalhes-base"
import { formatCurrency } from "../utils/formatCurrency"

export default function DetalhesTesouroDirecto({ ativo, isVisible, onClose }) {
  if (!ativo) return null

  // Cálculos
  const valorizacao = (ativo.netValue || 0) - (ativo.value || 0)
  const percentualValorizacao = ativo.value > 0 ? (valorizacao / ativo.value) * 100 : 0
  const isPositivo = valorizacao >= 0

  // Indicadores de rentabilidade
  const rentabilidadePositivaMonth = (ativo.monthProfitability || 0) >= 0
  const rentabilidadePositivaYear = (ativo.yearProfitability || 0) >= 0
  const rentabilidadePositiva12M = (ativo.last12monthsProfitability || 0) >= 0
  const rentabilidadePositivaAcum = (ativo.accumulatedProfitability || 0) >= 0

  // Data atual
  const dataAtual = new Date()
  const horaFormatada = dataAtual.toLocaleTimeString("pt-BR", {
    hour: "2-digit",
    minute: "2-digit",
  })
  const dataFormatada = dataAtual.toLocaleDateString("pt-BR", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
  })

  const actionButtons = (
    <div className="flex justify-between gap-3">
      <button
        className="bg-[#FDAA1A] hover:bg-[#F09800] text-white px-4 py-3 rounded-lg font-bold flex-1 transition-colors uppercase text-sm"
        onClick={() => console.log("Resgatar", ativo)}
      >
        <div className="flex items-center justify-center gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="17 8 12 3 7 8" />
            <line x1="12" y1="3" x2="12" y2="15" />
          </svg>
          Resgatar1
        </div>
      </button>
      <button
        className="bg-[#058CE1] hover:bg-[#006FB5] text-white px-4 py-3 rounded-lg font-bold flex-1 transition-colors uppercase text-sm"
        onClick={() => console.log("Investir", ativo)}
      >
        <div className="flex items-center justify-center gap-2">
          <svg
            xmlns="http://www.w3.org/2000/svg"
            width="16"
            height="16"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4" />
            <polyline points="7 10 12 15 17 10" />
            <line x1="12" y1="15" x2="12" y2="3" />
          </svg>
          Investir
        </div>
      </button>
    </div>
  )

  return (
    <DetalhesBase
      isVisible={isVisible}
      onClose={onClose}
      title={ativo.securitiesName || "Tesouro Direto"}
      subtitle={ativo.description || ""}
      actionButtons={actionButtons}
    >
      {/* Valor Atual */}
      <div className="p-4 border-b border-[#404040]">
        <div className="flex justify-between items-center mb-2">
          <h4 className="text-sm font-semibold text-[#aaa] uppercase">Valor Atual</h4>
          <div className="text-xs text-[#888]">
            Atualizado hoje às {horaFormatada} ({dataFormatada})
          </div>
        </div>

        <div className="text-2xl font-bold text-white mb-2">{formatCurrency(ativo.netValue || 0)}</div>

        <div className="flex items-center">
          <div className={`flex items-center ${isPositivo ? "text-[#21dd74]" : "text-[#d32f2f]"}`}>
            {isPositivo ? (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-1"
              >
                <path d="m18 15-6-6-6 6" />
              </svg>
            ) : (
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="16"
                height="16"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="mr-1"
              >
                <path d="m6 9 6 6 6-6" />
              </svg>
            )}
            <span className="font-medium">
              {formatCurrency(Math.abs(valorizacao))} ({percentualValorizacao.toFixed(2).replace(".", ",")}%)
            </span>
          </div>
        </div>
      </div>

      {/* Rentabilidade */}
      <div className="p-4 border-b border-[#404040] bg-[#2e2e2e]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Rentabilidade</h4>

        <div className="space-y-3">
          <div className="flex justify-between items-center">
            <span className="text-sm text-[#888]">No Mês</span>
            <div className={`flex items-center ${rentabilidadePositivaMonth ? "text-[#21dd74]" : "text-[#d32f2f]"}`}>
              {rentabilidadePositivaMonth ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-1"
                >
                  <path d="m18 15-6-6-6 6" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-1"
                >
                  <path d="m6 9 6 6 6-6" />
                </svg>
              )}
              <span className="font-medium">{(ativo.monthProfitability || 0).toFixed(2).replace(".", ",")}%</span>
            </div>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-sm text-[#888]">No Ano</span>
            <div className={`flex items-center ${rentabilidadePositivaYear ? "text-[#21dd74]" : "text-[#d32f2f]"}`}>
              {rentabilidadePositivaYear ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-1"
                >
                  <path d="m18 15-6-6-6 6" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-1"
                >
                  <path d="m6 9 6 6 6-6" />
                </svg>
              )}
              <span className="font-medium">{(ativo.yearProfitability || 0).toFixed(2).replace(".", ",")}%</span>
            </div>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-sm text-[#888]">Em 12 Meses</span>
            <div className={`flex items-center ${rentabilidadePositiva12M ? "text-[#21dd74]" : "text-[#d32f2f]"}`}>
              {rentabilidadePositiva12M ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-1"
                >
                  <path d="m18 15-6-6-6 6" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-1"
                >
                  <path d="m6 9 6 6 6-6" />
                </svg>
              )}
              <span className="font-medium">
                {(ativo.last12monthsProfitability || 0).toFixed(2).replace(".", ",")}%
              </span>
            </div>
          </div>

          <div className="flex justify-between items-center">
            <span className="text-sm text-[#888]">Acumulada</span>
            <div className={`flex items-center ${rentabilidadePositivaAcum ? "text-[#21dd74]" : "text-[#d32f2f]"}`}>
              {rentabilidadePositivaAcum ? (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-1"
                >
                  <path d="m18 15-6-6-6 6" />
                </svg>
              ) : (
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="14"
                  height="14"
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="mr-1"
                >
                  <path d="m6 9 6 6 6-6" />
                </svg>
              )}
              <span className="font-medium">{(ativo.accumulatedProfitability || 0).toFixed(2).replace(".", ",")}%</span>
            </div>
          </div>
        </div>
      </div>

      {/* Informações do Título */}
      <div className="p-4 border-b border-[#404040]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Informações do Título</h4>

        <div className="space-y-3">
          <div>
            <div className="text-xs text-[#888] mb-1">Tipo</div>
            <div className="font-medium">{ativo.typeName || "N/A"}</div>
          </div>

          <div>
            <div className="text-xs text-[#888] mb-1">Título</div>
            <div className="font-medium">{ativo.securitiesName || "N/A"}</div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <div className="text-xs text-[#888] mb-1">Vencimento</div>
              <div className="font-medium">
                {ativo.dueDate ? new Date(ativo.dueDate).toLocaleDateString("pt-BR") : "N/A"}
              </div>
            </div>
            <div>
              <div className="text-xs text-[#888] mb-1">Preço de Compra</div>
              <div className="font-medium">{formatCurrency(ativo.buyPrice || 0)}</div>
            </div>
          </div>
        </div>
      </div>

      {/* Minha Posição */}
      <div className="p-4 border-b border-[#404040] bg-[#2e2e2e]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Minha Posição</h4>

        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-xs text-[#888] mb-1">Quantidade Total</div>
            <div className="font-medium">
              {(ativo.currentBalance || 0).toLocaleString("pt-BR", { minimumFractionDigits: 2 })}
            </div>
          </div>
          <div>
            <div className="text-xs text-[#888] mb-1">Valor Aplicado</div>
            <div className="font-medium">{formatCurrency(ativo.value || 0)}</div>
          </div>
        </div>

        <div className="mt-4 pt-3 border-t border-[#404040]">
          <div className="flex justify-between items-center">
            <div className="text-xs text-[#888]">Valor Atual</div>
            <div className="text-lg font-bold">{formatCurrency(ativo.netValue || 0)}</div>
          </div>
        </div>
      </div>
    </DetalhesBase>
  )
}

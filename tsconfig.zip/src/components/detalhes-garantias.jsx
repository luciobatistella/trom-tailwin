"use client"

import { DetalhesBase } from "./detalhes-base"
import { formatCurrency } from "../utils/formatCurrency"

export default function DetalhesGarantias({ ativo, isVisible, onClose }) {
  if (!ativo) return null

  const actionButtons = (
    <div className="flex justify-between gap-3">
      <button
        className="bg-[#2196f3] hover:bg-[#1976d2] text-white px-4 py-3 rounded-lg font-bold flex-1 transition-colors uppercase text-sm"
        onClick={() => console.log("Consultar")}
      >
        Consultar
      </button>
      <button
        className="bg-[#757575] hover:bg-[#616161] text-white px-4 py-3 rounded-lg font-bold flex-1 transition-colors uppercase text-sm"
        onClick={() => console.log("Histórico")}
      >
        Histórico
      </button>
    </div>
  )

  return (
    <DetalhesBase
      isVisible={isVisible}
      onClose={onClose}
      title="Garantias"
      subtitle={ativo.description || "Garantia"}
      actionButtons={actionButtons}
    >
      {/* Informações da Garantia */}
      <div className="p-4 border-b border-[#404040]">
        <h4 className="text-sm font-semibold text-[#aaa] uppercase mb-3">Informações da Garantia</h4>
        <div className="space-y-2 text-sm">
          {ativo.dtCollateral && (
            <div className="flex justify-between">
              <span className="text-[#888]">Data da Garantia:</span>
              <span className="text-white">{ativo.dtCollateral}</span>
            </div>
          )}
          {ativo.collateral && (
            <div className="flex justify-between">
              <span className="text-[#888]">Tipo de Garantia:</span>
              <span className="text-white">{ativo.collateral}</span>
            </div>
          )}
          {ativo.qty && (
            <div className="flex justify-between">
              <span className="text-[#888]">Quantidade:</span>
              <span className="text-white">{ativo.qty}</span>
            </div>
          )}
          {ativo.value && (
            <div className="flex justify-between">
              <span className="text-[#888]">Valor:</span>
              <span className="text-white">{formatCurrency(ativo.value)}</span>
            </div>
          )}
          {ativo.currency && (
            <div className="flex justify-between">
              <span className="text-[#888]">Moeda:</span>
              <span className="text-white">{ativo.currency}</span>
            </div>
          )}
          {ativo.dtExpired && (
            <div className="flex justify-between">
              <span className="text-[#888]">Vencimento:</span>
              <span className="text-white">{ativo.dtExpired}</span>
            </div>
          )}
          {ativo.origin && (
            <div className="flex justify-between">
              <span className="text-[#888]">Origem:</span>
              <span className="text-white">{ativo.origin}</span>
            </div>
          )}
        </div>
      </div>
    </DetalhesBase>
  )
}

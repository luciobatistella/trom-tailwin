"use client"

import Custodia from "./Custodia"

export default function CustodiaTab() {
  return (
    <div className="h-full">
      <Custodia />
    </div>
  )
}

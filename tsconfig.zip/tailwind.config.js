/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        // Você pode adicionar suas cores personalizadas aqui
        // Por exemplo, baseado nas cores que vi no seu App.jsx:
        background: '#1e1e1e',
        primary: '#F7941E',  // Cor laranja que vi no componente Proventos
        success: '#21dd74',  // Cor verde que vi no componente Proventos
        dark: {
          100: '#353535',
          200: '#2a2a2a',
          300: '#1e1e1e',
          400: '#1C1C1C',
        }
      },
    },
  },
  plugins: [],
}